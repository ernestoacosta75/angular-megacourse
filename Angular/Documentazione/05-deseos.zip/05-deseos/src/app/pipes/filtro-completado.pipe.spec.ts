import { FiltroCompletadoPipe } from './filtro-completado.pipe';

describe('FiltroCompletadoPipe', () => {
  it('create an instance', () => {
    const pipe = new FiltroCompletadoPipe();
    expect(pipe).toBeTruthy();
  });
});
